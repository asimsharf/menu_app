* php artisan cache:clear
* php artisan optimize:clear
* composer dump-autoload
* composer clear-cache
* composer clearcache
* composer cc
* npm cache clean --force
* zip -r fileName.zip dirname | *