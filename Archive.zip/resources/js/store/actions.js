import axios from "axios";


//fetch all the categories from the api
export const getCategories = ({ commit }) => {
    axios.get(`/api/category`).then(res => {
        if (res.data.status == "success") {
            commit('SET_CATEGORIES', res.data.data);
        }
    }).catch(error => console.error(error));
}

//fetch all the products from the api
export const getProducts = ({ commit }) => {
    axios.get(`/api/product`).then(res => {
        if (res.data.status == "success") {
            commit('SET_PRODUCTS', res.data.data);
        }
    }).catch(error => console.error(error));
}

//fetch the product by the category
export const getProduct = ({ commit }, id) => {
    axios.get(`/api/product/${id}`).then(res => {
        if (res.data.status == "success") {
            commit('SET_PRODUCT', res.data.data);
        }
    }).catch(error => console.error(error));
}
