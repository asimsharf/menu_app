<template>
    <div>
        <h1>Register page</h1>
    </div>
</template>
